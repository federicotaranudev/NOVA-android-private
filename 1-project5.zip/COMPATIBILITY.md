# Compatibility and acceptance status

2026-10-24. Intended range Android8/API26 onward through current Android17/API37 family. This is an implementation target, NOT a tested support promise.

## Evidence
- Java sources compile against official Android37.2 android.jar. SDK metadata: non-preview API37.2 revision1, downloaded via official SDK manager.
- API lint NewApi/InlinedApi on compiled classes: no issues against declared min26.
- Full static lint:0 errors/9 warnings. Warnings include old target35, deliberate synchronous secret deletion, JavaScript enabled for the bundled app, icon/layout and hardcoded Italian text. No warning makes native runtime testing optional.
- No native .so libraries: APK contains DEX and assets, no ARM/x86-specific application binary requirement. This does not guarantee every device has a usable WebView or services.
- HTML browser regression uses actual local frontend with synthetic account/native callbacks. Zero errors. Not a WebView-on-Android test.
- Native app has not installed/launched in an operational Android runtime here. Software-only emulator failed to boot package/activity services in bounded attempts; no hardware acceleration available. Do not deliver existing old signed APK.

## Conditions and differences
- Android8/9: declared install floor, PIN fallback, updated system WebView needed. Official WebView docs say these OS releases no longer get new WebView releases. Legacy compatibility isn't a current security-support promise.
- Android10+: update Android System WebView independently; current official Chrome system requirements are Android10+.
- Android12+: exact alarms need special access; otherwise inexact scheduling is explicit.
- Android13+: notification runtime approval required.
- Android14+: foreground location requires while-in-use location access and visible-start conditions. Service never promises unrestricted continuous tracking.
- Android15+: safe system/keyboard insets explicitly applied; phone/tablet rendering needs actual runtime checks.
- Android17: source compile and documented changes reviewed; actual runtime unverified. targetSdk stays35 until latest behavior changes can be exercised. Installing on a newer OS and targeting its API are different claims.
- Internet needed for backend, map tiles, school/AI/music services. Credentials are entered by owner in app, not shared with testers. No Google Play Services dependency in native code.
- Biometric requires enrolled hardware or device credential fallback. Camera/mic/location optional permissions; denial must leave unrelated app usable.
- iOS lock-screen/live widgets are not ported equivalents. Android home widgets exist in source but visual layout unverified.

## Required acceptance before readiness
1. Install/open, cold launch, rotate, background/resume, keyboard/system bars on oldest practical updated-WebView device and current Android.
2. Sign in to isolated NOVA account, preserve real accounts, social privacy/friend-gating, chat media and logout. Clean synthetic data only.
3. Camera, mic recording/playback, file chooser, denied permissions.
4. Device credential/biometric set, cold and warm resume lock, cancel and no-enrollment paths.
5. Notifications normal/denied, one-shot exact/inexact, timers, reboot restore, homework opt-out/logout clearing.
6. Location denied/coarse/precise/off, stale/timed-out fixes; opt-in foreground service; ghost/logout immediately stops local updates and backend visibility. No automatic new sharing.
7. Timetable/homework and calendar widget visual/resizing/current date correctness.
8. ClasseViva/Groq/Spotify owner-authorized real integration tests, OAuth state/cancel/redirect and token refresh. No real credentials in fixtures or logs.
9. Latest Android behavior smoke tests and low-memory recovery. No compiler or browser mock can satisfy these device checks.

Official sources inspected:
https://developer.android.com/about/versions/17/summary
https://developer.android.com/about/versions/17/setup-sdk
https://developer.chrome.com/docs/webview
https://chromium.googlesource.com/chromium/src/+/refs/heads/main/android_webview/docs/prerelease.md
https://developer.android.com/studio/run/emulator-acceleration
https://support.google.com/chrome/a/answer/7100626?hl=en
