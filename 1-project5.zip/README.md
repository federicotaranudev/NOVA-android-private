# NOVA Android - first private test build

Version: 2026.10.24.android.1
Source UI: NOVA iOS24.5 commit3552518fb5adca7033c2c201284a956783dc91f9.
Package: site.federicotaranu.nova. Minimum declared API26, target35. Actual runtime compatibility is not verified.

## Status

This source revision supersedes the earlier signed private test APK. Do not deliver that artifact: newer static-audit fixes have not been signed or runtime-tested. Not a claim of full Android parity. Build and signature verification pass against official Android35 SDK. Embedded HTML byte check and browser pixel/bridge regressions pass. No Android device or fully booted emulator runtime test succeeded in this environment. No real credentials or profiles used for tests.

Implemented source paths: shared accounts/social/chat/UI; Keystore secret storage; ClasseViva/Groq/Spotify native calls; location and opt-in foreground sharing with persistent notification; reminders/alarms/reboot restore; imported-homework notifications and periodic register job; biometric/device credential lock; camera/microphone/file chooser; bundled narration/haptics; timetable+homework and calendar home widgets.

Android limits: exact alarms need special access; background jobs/location depend on OS/OEM controls, not guaranteed; force-stop stops background work. iOS lock-screen/live-widget variants are not Android equivalents. Widgets are source-built but not visually inspected on Android runtime yet. Credential/network service flows remain device-unverified. Current WebView support affects HTML/CSS/MediaRecorder and QR behavior. Spotify requires each user's developer client with nova://spotify-callback registered; browser OAuth cancellation is detected after return.

## Security

No secrets in this directory. Credentials on device encrypted with Android Keystore; backups disabled. Trusted-origin WebMessagePort; local bundled frontend libraries; CSP forbids remote scripts/frames. OAuth PKCE and state validation. Release signing key retained separately in owner's vault; never source control it. Uses existing backend/location revocation rules. No new paid services.

## Build

Official JDK17 + Android SDK35/build-tools35.0.0. build.sh uses a private signing keystore/password path supplied via NOVA_KEYSTORE/NOVA_KEYPASS_FILE. No Gradle or paid CI required. Keep the same signing key for updates. Do not publish a test artifact as a production or full-parity release.
