package site.federicotaranu.nova;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Storage for t=tt messages: timetable, open homework and month-calendar event dots,
 * shared with the home-screen widgets. Mirrors the iOS App Group files
 * (timetable.json / homework.json / events.json).
 *
 * INTEGRATION POINT (flagged): on Android there is no App Group. These payloads are
 * written to a dedicated SharedPreferences file that the widget provider(s) can read
 * via NovaWidgetStore.timetable(ctx) / homework(ctx) / events(ctx). The widget layer
 * (owned by the primary builder) should call these getters when building RemoteViews.
 * iOS also has a "widget ping" liveness file; there is no Android equivalent yet, so
 * ping is reported false until the widget layer writes one via markPing().
 */
public final class NovaWidgetStore {
    private static final String PREFS = "nova_widget_store";
    private static final String K_TIMETABLE = "timetable.json";
    private static final String K_HOMEWORK = "homework.json";
    private static final String K_EVENTS = "events.json";
    private static final String K_PING = "widget_ping";

    private NovaWidgetStore() { }

    private static SharedPreferences prefs(Context ctx) {
        return ctx.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static void saveTimetable(Context ctx, String json) {
        prefs(ctx).edit().putString(K_TIMETABLE, json).apply();
    }

    public static void saveHomework(Context ctx, String json) {
        prefs(ctx).edit().putString(K_HOMEWORK, json).apply();
    }

    public static void saveEvents(Context ctx, String json) {
        prefs(ctx).edit().putString(K_EVENTS, json).apply();
    }

    public static String timetable(Context ctx) { return prefs(ctx).getString(K_TIMETABLE, null); }
    public static String homework(Context ctx) { return prefs(ctx).getString(K_HOMEWORK, null); }
    public static String events(Context ctx) { return prefs(ctx).getString(K_EVENTS, null); }

    /** Widget layer calls this once it has actually rendered from the store. */
    public static void markPing(Context ctx) {
        prefs(ctx).edit().putLong(K_PING, System.currentTimeMillis()).apply();
    }

    public static boolean widgetPing(Context ctx) {
        return prefs(ctx).contains(K_PING);
    }
}
