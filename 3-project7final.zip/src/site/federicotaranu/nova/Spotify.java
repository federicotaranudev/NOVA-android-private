package site.federicotaranu.nova;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.util.Base64;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Spotify Web API client with PKCE login. Android port of the iOS bridge.
 * Ops: status / setcid / logout / login / state / play / pause / next / prev.
 * Refresh token and cached access token live only in the Keystore-backed SecureStore.
 *
 * ANDROID LOGIN FLOW (flagged integration point, replaces ASWebAuthenticationSession):
 *  1. JS sends op=login -> we store the PKCE verifier, remember the reply id, launch
 *     the authorize URL in the browser, and DO NOT reply yet (the JS promise stays open).
 *  2. MANIFEST: the host app must register an intent-filter for scheme "nova",
 *     host "spotify-callback" and forward the received Uri to
 *     NovaIntegrations.onSpotifyRedirect(uri) (e.g. from onNewIntent).
 *  3. We then exchange the code and finally reply to the original request id.
 *  4. If the auth screen closes without a redirect, the host should call
 *     NovaIntegrations.onSpotifyLoginCancelled() so the JS promise resolves with denied.
 * A plain ACTION_VIEW intent is used to avoid an androidx.browser dependency; the
 * primary builder can swap in a Chrome Custom Tab (better UX) without touching this class.
 */
final class Spotify {
    private static final String REDIRECT = "nova://spotify-callback";
    private static final String SCOPES = "user-read-playback-state user-modify-playback-state";
    private static final String PREFS = "nova_spotify";
    private static final String K_VERIFIER = "pkce_verifier";

    private final Context app;
    private final SecretBox secrets;

    /** Pending login request id waiting for the deep-link redirect; -1 = none. */
    private volatile int pendingLoginId = -1;

    Spotify(Context ctx, SecretBox secrets) {
        this.app = ctx.getApplicationContext();
        this.secrets = secrets;
    }

    private String cid() {
        String v = secrets.get("spotify.cid");
        return v == null ? "" : v;
    }

    interface ReplySink {
        void send(int id, JSONObject result);
    }

    /** Returns the reply JSONObject, or null when the reply is deferred (login). */
    JSONObject handle(JSONObject msg, int reqId) {
        switch (msg.optString("op", "")) {
            case "status": {
                JSONObject r = ClasseViva.ok();
                try {
                    r.put("cid", cid().isEmpty() ? 0 : 1);
                    r.put("conn", secrets.get("spotify.refresh") != null ? 1 : 0);
                } catch (JSONException ignored) { }
                return r;
            }
            case "setcid": {
                String v = msg.optString("cid", "").trim();
                if (v.isEmpty()) secrets.remove("spotify.cid"); else secrets.put("spotify.cid", v);
                secrets.remove("spotify.refresh");
                secrets.remove("spotify.access");
                return ClasseViva.ok();
            }
            case "logout":
                secrets.remove("spotify.refresh");
                secrets.remove("spotify.access");
                return ClasseViva.ok();
            case "login": {
                JSONObject errReply = startLogin(reqId);
                return errReply; // null = reply deferred until onSpotifyRedirect / onSpotifyLoginCancelled
            }
            case "state":
                return state();
            case "play": return control("PUT", "/me/player/play");
            case "pause": return control("PUT", "/me/player/pause");
            case "next": return control("POST", "/me/player/next");
            case "prev": return control("POST", "/me/player/previous");
            default:
                return ClasseViva.err("op");
        }
    }

    boolean hasPendingLogin() { return pendingLoginId >= 0; }

    void cancelPendingLogin(ReplySink sink) {
        if (pendingLoginId >= 0) {
            int id = pendingLoginId;
            pendingLoginId = -1;
            secrets.remove(K_VERIFIER);secrets.remove("spotify.state");
            sink.send(id, ClasseViva.err("denied"));
        }
    }

    // ---- PKCE login ----

    /** Returns an error reply on synchronous failure, or null when the browser was launched. */
    private JSONObject startLogin(int reqId) {
        String id = cid();
        if (id.isEmpty()) { pendingLoginId = -1; return ClasseViva.err("nocid"); }
        String verifier = randomString(64);
        secrets.put(K_VERIFIER, verifier);String state=randomString(40);secrets.put("spotify.state",state);
        pendingLoginId = reqId;
        String challenge;
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(verifier.getBytes("UTF-8"));
            challenge = Base64.encodeToString(hash, Base64.URL_SAFE | Base64.NO_PADDING | Base64.NO_WRAP);
        } catch (Exception e) {
            pendingLoginId = -1;
            secrets.remove(K_VERIFIER);secrets.remove("spotify.state");return ClasseViva.err("client");
        }
        String url = "https://accounts.spotify.com/authorize"
                + "?client_id=" + formEncode(id)
                + "&state=" + formEncode(state) + "&response_type=code"
                + "&redirect_uri=" + formEncode(REDIRECT)
                + "&code_challenge_method=S256"
                + "&code_challenge=" + formEncode(challenge)
                + "&scope=" + formEncode(SCOPES);
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            app.startActivity(i);
        } catch (Exception e) {
            pendingLoginId = -1;
            secrets.remove(K_VERIFIER);secrets.remove("spotify.state");return ClasseViva.err("client");
        }
        return null; // launched: reply deferred
    }

    /** Call from the host when the nova://spotify-callback deep link arrives. Off-thread ok. */
    void onRedirect(Uri uri, ReplySink sink) {
        if (pendingLoginId < 0) return;
        int id = pendingLoginId;
        pendingLoginId = -1;
        String code = uri.getQueryParameter("code");
        String verifier = secrets.get(K_VERIFIER);String expectedState=secrets.get("spotify.state");
        secrets.remove(K_VERIFIER);secrets.remove("spotify.state");
        if (!"nova".equals(uri.getScheme())||!"spotify-callback".equals(uri.getHost())||expectedState==null||!expectedState.equals(uri.getQueryParameter("state"))||code == null || verifier == null) {
            sink.send(id, ClasseViva.err("denied"));
            return;
        }
        Map<String, String> params = new LinkedHashMap<>();
        params.put("client_id", cid());
        params.put("grant_type", "authorization_code");
        params.put("code", code);
        params.put("redirect_uri", REDIRECT);
        params.put("code_verifier", verifier);
        int[] status = new int[1];
        JSONObject j = tokenRequest(params, status);
        if (status[0] != 200 || j == null) {
            sink.send(id, ClasseViva.errInfo(status[0] == 0 ? "rete" : "client", "HTTP " + status[0]));
            return;
        }
        storeTokens(j);
        sink.send(id, ClasseViva.ok());
    }

    // ---- tokens ----

    private SharedPreferences prefs() {
        return app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static String randomString(int n) {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~";
        SecureRandom rnd = new SecureRandom();
        StringBuilder sb = new StringBuilder(n);
        for (int i = 0; i < n; i++) sb.append(chars.charAt(rnd.nextInt(chars.length())));
        return sb.toString();
    }

    /** Matches the Swift form encoder: only alphanumerics stay literal. */
    private static String formEncode(String v) {
        StringBuilder sb = new StringBuilder();
        for (char c : v.toCharArray()) {
            if (Character.isLetterOrDigit(c)) sb.append(c);
            else {
                try { sb.append(URLEncoder.encode(String.valueOf(c), "UTF-8").replace("+", "%20")); }
                catch (Exception e) { sb.append(c); }
            }
        }
        return sb.toString();
    }

    /** Returns parsed token response (with _status), or null on network failure; status[0] = HTTP code (0 = network). */
    private JSONObject tokenRequest(Map<String, String> params, int[] status) {
        StringBuilder body = new StringBuilder();
        boolean first = true;
        for (Map.Entry<String, String> e : params.entrySet()) {
            if (!first) body.append('&');
            first = false;
            body.append(e.getKey()).append('=').append(formEncode(e.getValue()));
        }
        try {
            java.net.HttpURLConnection conn = (java.net.HttpURLConnection)
                    new java.net.URL("https://accounts.spotify.com/api/token").openConnection();
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(20000);
            conn.setReadTimeout(20000);
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            conn.setDoOutput(true);
            byte[] bytes = body.toString().getBytes("UTF-8");
            conn.setRequestProperty("Content-Length", String.valueOf(bytes.length));
            try (java.io.OutputStream os = conn.getOutputStream()) { os.write(bytes); }
            status[0] = conn.getResponseCode();
            java.io.InputStream is = status[0] >= 400 ? conn.getErrorStream() : conn.getInputStream();
            String text = "";
            if (is != null) {
                StringBuilder sb = new StringBuilder();
                try (java.io.BufferedReader br = new java.io.BufferedReader(
                        new java.io.InputStreamReader(is, "UTF-8"))) {
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line).append('\n');
                }
                text = sb.toString();
            }
            conn.disconnect();
            return new JSONObject(text);
        } catch (Exception e) {
            status[0] = 0;
            return null;
        }
    }

    private void storeTokens(JSONObject j) {
        String access = j.optString("access_token", null);
        if (access != null) {
            long exp = System.currentTimeMillis() / 1000L + j.optLong("expires_in", 3600);
            JSONObject d = new JSONObject();
            try { d.put("t", access); d.put("e", (double) exp); } catch (JSONException ignored) { }
            secrets.put("spotify.access", d.toString());
        }
        String refresh = j.optString("refresh_token", null);
        if (refresh != null) secrets.put("spotify.refresh", refresh);
    }

    private String accessToken(boolean force) {
        if (!force) {
            String raw = secrets.get("spotify.access");
            if (raw != null) {
                try {
                    JSONObject d = new JSONObject(raw);
                    if (d.optDouble("e", 0) > System.currentTimeMillis() / 1000.0 + 30) {
                        return d.optString("t", null);
                    }
                } catch (JSONException ignored) { }
            }
        }
        String refresh = secrets.get("spotify.refresh");
        if (refresh == null || cid().isEmpty()) return null;
        Map<String, String> params = new LinkedHashMap<>();
        params.put("client_id", cid());
        params.put("grant_type", "refresh_token");
        params.put("refresh_token", refresh);
        int[] status = new int[1];
        JSONObject j = tokenRequest(params, status);
        if (status[0] != 200 || j == null) return null;
        storeTokens(j);
        return j.optString("access_token", null);
    }

    // ---- Web API ----

    /** Returns {status, body} or null on network failure. Retries once with a forced refresh on 401. */
    private int[] apiWithData(String method, String path, StringBuilder outBody) {
        for (int attempt = 0; attempt < 2; attempt++) {
            String token = accessToken(attempt == 1);
            if (token == null) return new int[]{401};
            try {
                java.net.HttpURLConnection conn = (java.net.HttpURLConnection)
                        new java.net.URL("https://api.spotify.com/v1" + path).openConnection();
                conn.setRequestMethod(method);
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(15000);
                conn.setRequestProperty("Authorization", "Bearer " + token);
                if (!"GET".equals(method)) {
                    conn.setRequestProperty("Content-Length", "0");
                    conn.setDoOutput(true);
                    conn.getOutputStream().close();
                }
                int status = conn.getResponseCode();
                java.io.InputStream is = status >= 400 ? conn.getErrorStream() : conn.getInputStream();
                StringBuilder sb = new StringBuilder();
                if (is != null) {
                    try (java.io.BufferedReader br = new java.io.BufferedReader(
                            new java.io.InputStreamReader(is, "UTF-8"))) {
                        String line;
                        while ((line = br.readLine()) != null) sb.append(line).append('\n');
                    }
                }
                conn.disconnect();
                if (status == 401 && attempt == 0) continue;
                outBody.append(sb);
                return new int[]{status};
            } catch (Exception e) { return null; }
        }
        return null;
    }

    private JSONObject fail(int status, String body) {
        if (status == 401) return ClasseViva.err("auth");
        if (status == 404) return ClasseViva.err("nodevice");
        if (status == 403) {
            String reason = "";
            try {
                JSONObject j = new JSONObject(body);
                reason = j.optJSONObject("error") != null ? j.optJSONObject("error").optString("reason", "") : "";
            } catch (JSONException ignored) { }
            return ClasseViva.errInfo("PREMIUM_REQUIRED".equals(reason) ? "premium" : "client", reason);
        }
        return ClasseViva.errInfo("rete", "HTTP " + status);
    }

    private JSONObject state() {
        StringBuilder body = new StringBuilder();
        int[] res = apiWithData("GET", "/me/player", body);
        if (res == null) return ClasseViva.err("rete");
        if (res[0] == 204) { JSONObject r = ClasseViva.ok(); try { r.put("idle", 1); } catch (JSONException ignored) { } return r; }
        if (res[0] != 200) return fail(res[0], body.toString());
        try {
            JSONObject j = new JSONObject(body.toString());
            JSONObject item = j.optJSONObject("item");
            if (item == null) { JSONObject r = ClasseViva.ok(); r.put("idle", 1); return r; }
            StringBuilder artists = new StringBuilder();
            org.json.JSONArray arr = item.optJSONArray("artists");
            if (arr != null) {
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject a = arr.optJSONObject(i);
                    if (a == null) continue;
                    if (artists.length() > 0) artists.append(", ");
                    artists.append(a.optString("name", ""));
                }
            }
            String img = "";
            JSONObject album = item.optJSONObject("album");
            org.json.JSONArray imgs = album != null ? album.optJSONArray("images") : null;
            if (imgs != null && imgs.length() > 0) {
                JSONObject pick = imgs.length() > 1 ? imgs.optJSONObject(1) : imgs.optJSONObject(0);
                if (pick != null) img = pick.optString("url", "");
            }
            JSONObject r = ClasseViva.ok();
            r.put("playing", j.optBoolean("is_playing", false) ? 1 : 0);
            r.put("track", item.optString("name", ""));
            r.put("artist", artists.toString());
            r.put("img", img);
            return r;
        } catch (JSONException e) {
            JSONObject r = ClasseViva.ok();
            try { r.put("idle", 1); } catch (JSONException ignored) { }
            return r;
        }
    }

    private JSONObject control(String method, String path) {
        StringBuilder body = new StringBuilder();
        int[] res = apiWithData(method, path, body);
        if (res == null) return ClasseViva.err("rete");
        if (res[0] == 200 || res[0] == 202 || res[0] == 204) return ClasseViva.ok();
        return fail(res[0], body.toString());
    }
}
