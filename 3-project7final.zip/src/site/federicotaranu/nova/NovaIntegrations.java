package site.federicotaranu.nova;

import android.content.Context;
import android.net.Uri;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Native bridge dispatcher for NOVA Android. Handles the service/network messages the
 * shared nova.html frontend sends through the trusted WebView bridge:
 *   t=classeviva (login/refresh/logout + events/grades import)
 *   t=groq       (has/clear/set/chat/vision)
 *   t=spotify    (status/setcid/logout/login/state/play/pause/next/prev)
 *   t=tt         (timetable/homework sharing with the home-screen widgets)
 *
 * Contract with the host (primary builder):
 *  - Construct once with a Context and a Reply sink. Replies go to the frontend as
 *    __novaCV(id, result) exactly like iOS; marshaling that JS call onto the main
 *    thread is the host's job. Reply.send is invoked from a background thread.
 *  - handle(JSONObject) never blocks the caller: work runs on a single background
 *    executor (keeps Spotify's deferred-login reply ordering sane).
 *  - Secrets go through the Keystore-backed SecureStore (wrapped once in SecretBox).
 *  - Manifest must register the nova://spotify-callback deep link and forward it to
 *    onSpotifyRedirect(Uri); call onSpotifyLoginCancelled() if the auth screen closes
 *    without a redirect. See Spotify.java's header for details.
 *  - Homework reminder scheduling (iOS HomeNotifs) is NOT here: register an
 *    EventsListener via setEventsListener to receive imported events and schedule
 *    alarms/notifications in the host layer. backgroundRefresh() is the WorkManager
 *    entry point for the periodic register refresh.
 */
public final class NovaIntegrations {

    public interface Reply {
        void send(int id, JSONObject result);
    }

    private final Context app;
    private final Reply reply;
    private final SecretBox secrets;
    private final ClasseViva classeViva;
    private final Groq groq;
    private final Spotify spotify;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final ExecutorService schoolIo = Executors.newSingleThreadExecutor();
    private final ExecutorService aiIo = Executors.newSingleThreadExecutor();

    public NovaIntegrations(Context ctx, Reply reply) {
        this.app = ctx.getApplicationContext();
        this.reply = reply;
        this.secrets = new SecretBox(app);
        this.classeViva = new ClasseViva(app, secrets, null);
        this.groq = new Groq(secrets);
        this.spotify = new Spotify(app, secrets);
    }

    /** Host supplies the homework-notification scheduler (iOS: HomeNotifs). */
    public void setEventsListener(ClasseViva.EventsListener listener) {
        classeViva.setEventsListener(listener);
    }

    /** JS bridge entry point. Called by the host for every {t, op, id, ...} message. */
    public void handle(final JSONObject message) {
        final String t = message.optString("t", "");
        final int reqId = message.optInt("id", 0);
        switch (t) {
            case "classeviva":
            case "groq":
            case "spotify":
            case "tt":
                ("classeviva".equals(t)?schoolIo:"groq".equals(t)?aiIo:io).execute(new Runnable() {
                    @Override public void run() { dispatch(t, message, reqId); }
                });
                break;
            default:
                // Not ours: the host owns perm/reminders/haptics/location/audio/faceid/etc.
                break;
        }
    }

    private void dispatch(String t, JSONObject message, int reqId) {
        try {
            switch (t) {
                case "classeviva":
                    reply.send(reqId, classeViva.handle(message));
                    break;
                case "groq":
                    reply.send(reqId, groq.handle(message));
                    break;
                case "spotify":
                    handleSpotify(message, reqId);
                    break;
                case "tt":
                    reply.send(reqId, handleTimetable(message));
                    break;
                default:
                    break;
            }
        } catch (Throwable th) {
            reply.send(reqId, ClasseViva.errInfo("rete", String.valueOf(th.getMessage())));
        }
    }

    private void handleSpotify(JSONObject message, int reqId) {
        try {
            JSONObject r = spotify.handle(message, reqId);
            if (r != null) reply.send(reqId, r); // null = deferred (login in browser)
        } catch (Throwable th) {
            reply.send(reqId, ClasseViva.errInfo("rete", String.valueOf(th.getMessage())));
        }
    }

    /** Deep-link entry point called by MainActivity on newIntent (contract name).
     *  Forward the nova://spotify-callback Uri here. */
    public void handleRedirect(final Uri uri) {
        onSpotifyRedirect(uri);
    }

    /** Forward the nova://spotify-callback deep link here (from the host Activity). */
    public void onSpotifyRedirect(final Uri uri) {
        io.execute(new Runnable() {
            @Override public void run() {
                spotify.onRedirect(uri, new Spotify.ReplySink() {
                    @Override public void send(int id, JSONObject result) { reply.send(id, result); }
                });
            }
        });
    }

    /** Call when the Spotify auth screen closes with no redirect (user cancelled). */
    public void onSpotifyLoginCancelled() {
        io.execute(new Runnable() {
            @Override public void run() {
                spotify.cancelPendingLogin(new Spotify.ReplySink() {
                    @Override public void send(int id, JSONObject result) { reply.send(id, result); }
                });
            }
        });
    }

    public boolean hasPendingSpotifyLogin() { return spotify.hasPendingLogin(); }

    /** Periodic ClasseViva refresh (WorkManager entry point). True when it succeeded. */
    public boolean backgroundRefresh() {
        return classeViva.backgroundRefresh();
    }

    // ---- t=tt: share timetable / homework with the home-screen widgets ----

    private JSONObject handleTimetable(JSONObject message) {
        String op = message.optString("op", "");
        String json = message.optString("json", "");
        JSONObject r = ClasseViva.ok();
        try {
            if ("hw".equals(op)) {
                NovaWidgetStore.saveHomework(app, json);
                r.put("shared", true);
            } else {
                NovaWidgetStore.saveTimetable(app, json);
                r.put("shared", true);
                r.put("ping", NovaWidgetStore.widgetPing(app));
                r.put("groups", new org.json.JSONArray().put("nova_widget_store"));
            }
        } catch (JSONException ignored) { }
        return r;
    }
}
