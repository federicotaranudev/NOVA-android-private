package site.federicotaranu.nova;

import android.content.Context;

/**
 * Single adapter over the primary builder's Keystore-backed SecureStore.
 * If the supplied SecureStore API differs, fix it HERE only.
 * Expected: new SecureStore(context); String get(String key); void put(String key, String value); void remove(String key).
 * All credentials (ClasseViva uid/pass, Groq key, Spotify refresh token) live here, never in plaintext prefs.
 */
final class SecretBox {
    private final SecureStore store;

    SecretBox(Context ctx) {
        this.store = new SecureStore(ctx.getApplicationContext());
    }

    String get(String key) {
        try { return store.get(key); } catch (Throwable t) { return null; }
    }

    void put(String key, String value) {
        store.put(key, value);
    }

    void remove(String key) {
        try { store.remove(key); } catch (Throwable ignored) { }
    }
}
