package site.federicotaranu.nova;
import android.content.*;import android.app.*;import android.os.*;import org.json.*;import java.util.*;import java.text.*;
final class WidgetData {
 static final TimeZone ZONE=TimeZone.getTimeZone("Europe/Rome");
 static Calendar calendar(long t){Calendar c=Calendar.getInstance(ZONE,Locale.ITALIAN);c.setTimeInMillis(t);return c;}
 static String date(long t){SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd",Locale.ROOT);f.setTimeZone(ZONE);return f.format(new Date(t));}
 static String time(long t){SimpleDateFormat f=new SimpleDateFormat("HH:mm",Locale.ITALIAN);f.setTimeZone(ZONE);return f.format(new Date(t));}
 static String dayTime(long t){SimpleDateFormat f=new SimpleDateFormat("EEE HH:mm",Locale.ITALIAN);f.setTimeZone(ZONE);return f.format(new Date(t));}
 static JSONArray array(String raw,String key){try{return new JSONObject(raw==null?"{}":raw).optJSONArray(key);}catch(Exception e){return null;}}
 static class Slot{long start,end;String name,room;Slot(long s,long e,String n,String r){start=s;end=e;name=n;room=r;}String label(){return name+(room.isEmpty()?"":" · "+room);} }
 static List<Slot> slots(Context c,long now,int days){ArrayList<Slot> out=new ArrayList<>();JSONArray rows=array(NovaWidgetStore.timetable(c),"lessons");if(rows==null)return out;
  for(int i=0;i<days;i++){Calendar d=calendar(now);d.add(Calendar.DATE,i);for(int n=0;n<rows.length();n++){JSONObject j=rows.optJSONObject(n);if(j==null||j.optInt("d")!=d.get(Calendar.DAY_OF_WEEK))continue;int s=j.optInt("s",-1),e=j.optInt("e",-1);if(s<0||e<=s||e>1440)continue;Calendar a=(Calendar)d.clone(),b=(Calendar)d.clone();a.set(Calendar.HOUR_OF_DAY,s/60);a.set(Calendar.MINUTE,s%60);a.set(Calendar.SECOND,0);a.set(Calendar.MILLISECOND,0);b.set(Calendar.HOUR_OF_DAY,e/60);b.set(Calendar.MINUTE,e%60);b.set(Calendar.SECOND,0);b.set(Calendar.MILLISECOND,0);out.add(new Slot(a.getTimeInMillis(),b.getTimeInMillis(),j.optString("n"),j.optString("r").trim()));}}
  Collections.sort(out,(a,b)->Long.compare(a.start,b.start));return out;
 }
 static Slot currentOrNext(List<Slot> slots,long now){for(Slot s:slots)if(s.end>now)return s;return null;}
 static List<Slot> today(List<Slot> slots,long now){ArrayList<Slot> out=new ArrayList<>();for(Slot s:slots)if(date(s.start).equals(date(now)))out.add(s);return out;}
 static long homeworkTarget(long now){Calendar c=calendar(now);int wd=c.get(Calendar.DAY_OF_WEEK);int add=wd>=2&&wd<=5?1:wd==6?3:wd==7?2:1;c.add(Calendar.DATE,add);c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);return c.getTimeInMillis();}
 static List<JSONObject> homework(Context c,long target){ArrayList<JSONObject> out=new ArrayList<>();JSONArray a=array(NovaWidgetStore.homework(c),"items");if(a!=null)for(int i=0;i<a.length();i++){JSONObject j=a.optJSONObject(i);if(j!=null&&date(target).equals(j.optString("d")))out.add(j);}return out;}
 static String homeworkLabel(long now,long target){Calendar tomorrow=calendar(now);tomorrow.add(Calendar.DATE,1);if(date(tomorrow.getTimeInMillis()).equals(date(target)))return "domani";SimpleDateFormat f=new SimpleDateFormat("EEEE",Locale.ITALIAN);f.setTimeZone(ZONE);return f.format(new Date(target));}
 static void schedule(Context c){android.appwidget.AppWidgetManager wm=android.appwidget.AppWidgetManager.getInstance(c);int count=0;for(Class<?> k:new Class<?>[]{NovaWidget.class,CalendarWidget.class,OrarioWidget.class,OggiWidget.class,FineWidget.class,CompitiWidget.class})count+=wm.getAppWidgetIds(new ComponentName(c,k)).length;
  AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);PendingIntent pi=PendingIntent.getBroadcast(c,804,new Intent(c,WidgetRefreshReceiver.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);am.cancel(pi);if(count==0)return;
  long now=System.currentTimeMillis();Calendar d=calendar(now);d.add(Calendar.DATE,1);d.set(Calendar.HOUR_OF_DAY,0);d.set(Calendar.MINUTE,0);d.set(Calendar.SECOND,0);d.set(Calendar.MILLISECOND,0);long next=d.getTimeInMillis();for(Slot s:slots(c,now,2)){if(s.start>now)next=Math.min(next,s.start);if(s.end>now)next=Math.min(next,s.end);}try{if(Build.VERSION.SDK_INT<31||am.canScheduleExactAlarms())am.setExact(AlarmManager.RTC,next,pi);else am.setWindow(AlarmManager.RTC,next,600000,pi);}catch(SecurityException e){am.setWindow(AlarmManager.RTC,next,600000,pi);}
 }
}
