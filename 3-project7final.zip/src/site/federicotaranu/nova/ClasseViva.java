package site.federicotaranu.nova;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * ClasseViva REST client (web.spaggiari.eu/rest/v1), Android port of the iOS bridge.
 * Same message contract: ops login / refresh / logout, replies via JSONObject with
 * ok/err/needChoice/choices/name/events/grades as in the Swift version.
 * Credentials are kept ONLY in the Keystore-backed SecureStore (via SecretBox).
 * Must be called off the main thread (NovaIntegrations does that).
 */
final class ClasseViva {
    private static final String BASE = "https://web.spaggiari.eu/rest/v1";

    // Header pairs used by documented open-source clients: if one API key stops
    // being accepted, the other is tried automatically (same as iOS).
    private static final String[][] HEADER_PAIRS = {
        {"CVVS/std/4.1.7 Android/10", "Tg1NWEwNGIgIC0K"},
        {"zorro/1.0", "+zorro+"}
    };

    /** Fired after every successful login/refresh with the imported events. The host
     *  (primary builder) schedules homework reminder alarms/notifications from this. */
    interface EventsListener {
        void onEvents(JSONArray events, boolean background);
    }

    private final Context app;
    private final SecretBox secrets;
    private volatile EventsListener listener;

    ClasseViva(Context ctx, SecretBox secrets, EventsListener listener) {
        this.app = ctx.getApplicationContext();
        this.secrets = secrets;
        this.listener = listener;
    }

    void setEventsListener(EventsListener l) { this.listener = l; }

    // ---- credentials (Keychain equivalent) ----

    private void saveCreds(String uid, String pass) {
        JSONObject j = new JSONObject();
        try { j.put("uid", uid); j.put("pass", pass); } catch (JSONException ignored) { }
        secrets.put("classeviva.login", j.toString());
    }

    private String[] readCreds() {
        String raw = secrets.get("classeviva.login");
        if (raw == null) return null;
        try {
            JSONObject j = new JSONObject(raw);
            return new String[]{j.getString("uid"), j.getString("pass")};
        } catch (JSONException e) { return null; }
    }

    private void clearCreds() { secrets.remove("classeviva.login"); }

    // ---- message entry point ----

    JSONObject handle(JSONObject msg) {
        String op = msg.optString("op", "");
        switch (op) {
            case "logout":
                clearCreds();
                Notifications.schedule(app,"hw",null);secrets.remove("hw.known");NovaWidgetStore.saveEvents(app,"{}");NovaWidgetStore.saveHomework(app,"{}");NovaWidget.refresh(app);
                return ok();
            case "login": {
                String uid = msg.optString("uid", "");
                String pass = msg.optString("pass", "");
                if (uid.isEmpty() || pass.isEmpty()) return err("dati");
                String ident = msg.has("ident") ? msg.optString("ident", null) : null;
                return loginFlow(uid, pass, ident, true, false);
            }
            case "refresh": {
                String[] c = readCreds();
                if (c == null) return err("no-creds");
                return loginFlow(c[0], c[1], null, false, false);
            }
            default:
                return err("op");
        }
    }

    boolean backgroundRefresh() {
        String[] c = readCreds();
        if (c == null) return false;
        JSONObject r = loginFlow(c[0], c[1], null, false, true);
        return r.optInt("ok", 0) == 1;
    }

    // ---- login flow (dual header-pair fallback, family-account choices) ----

    private JSONObject loginFlow(String uid, String pass, String ident, boolean save, boolean background) {
        JSONObject payload = new JSONObject();
        try {
            payload.put("uid", uid);
            payload.put("pass", pass);
            payload.put("ident", (ident != null && !ident.isEmpty()) ? ident : JSONObject.NULL);
        } catch (JSONException e) { return err("dati"); }

        for (int pair = 0; pair < HEADER_PAIRS.length; pair++) {
            HttpResult res;
            try {
                res = call("/auth/login", "POST", payload, null, pair);
            } catch (Exception e) {
                return errInfo("rete", e.getMessage());
            }
            JSONObject j = res.json();
            if (j == null) {
                // Non-JSON response (e.g. firewall 403): try the next pair.
                if (pair + 1 < HEADER_PAIRS.length) continue;
                return errInfo("bloccato", "HTTP " + res.status);
            }
            String e = j.optString("error", "").toLowerCase(Locale.ROOT);
            if ((e.contains("apikey") || e.contains("api key")) && pair + 1 < HEADER_PAIRS.length) continue;

            // Family account with several profiles: the app lets the user pick the student.
            JSONArray choices = j.optJSONArray("choices");
            if (choices != null && choices.length() > 0) {
                JSONObject r = err("credenziali");
                r.remove("err");
                try { r.put("ok", 0); r.put("needChoice", 1); } catch (JSONException ignored) { }
                JSONArray list = new JSONArray();
                for (int i = 0; i < choices.length(); i++) {
                    JSONObject c = choices.optJSONObject(i);
                    if (c == null) continue;
                    JSONObject o = new JSONObject();
                    try {
                        o.put("ident", c.optString("ident", ""));
                        o.put("name", c.optString("name", ""));
                        o.put("school", c.optString("school", ""));
                    } catch (JSONException ignored) { }
                    list.put(o);
                }
                try { r.put("choices", list); } catch (JSONException ignored) { }
                return r;
            }

            String token = j.optString("token", null);
            String fullIdent = j.optString("ident", null);
            if (res.status != 200 || token == null || fullIdent == null) {
                String info = (j.optString("info", "") + " " + j.optString("error", "")).trim();
                return errInfo("credenziali", ("HTTP " + res.status + " " + info).trim());
            }

            String studentID = fullIdent.replaceAll("[A-Za-z]", "");
            if (save) saveCreds(uid, pass);
            String name = (j.optString("firstName", "") + " " + j.optString("lastName", "")).trim();

            JSONArray events = fetchEvents(token, studentID, pair);
            JSONArray grades = gradesItems(token, studentID, pair);
            shareWithWidgets(events);
            if (listener != null) listener.onEvents(events, background);

            JSONObject r = ok();
            try {
                r.put("name", name);
                r.put("events", events);
                r.put("grades", grades);
            } catch (JSONException ignored) { }
            return r;
        }
        return errInfo("rete", "nessuna risposta");
    }

    // Share month-calendar dots + open homework with the widgets (iOS: App Group files).
    private void shareWithWidgets(JSONArray events) {
        SimpleDateFormat mdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.DAY_OF_MONTH, 1);
        String monthStart = mdf.format(cal.getTime());
        String today = mdf.format(new Date());

        Set<String> seen = new LinkedHashSet<>();
        JSONArray dots = new JSONArray();
        JSONArray hwItems = new JSONArray();
        for (int i = 0; i < events.length(); i++) {
            JSONObject ev = events.optJSONObject(i);
            if (ev == null) continue;
            String d = ev.optString("date", "");
            String kind = "test".equals(ev.optString("kind")) ? "test" : "hw";
            if (!d.isEmpty() && d.compareTo(monthStart) >= 0 && seen.add(d + "|" + kind)) {
                JSONObject dot = new JSONObject();
                try { dot.put("d", d); dot.put("k", kind); } catch (JSONException ignored) { }
                dots.put(dot);
            }
            if ("hw".equals(kind) && !d.isEmpty() && d.compareTo(today) >= 0) {
                JSONObject item = new JSONObject();
                try {
                    item.put("t", ev.optString("title", ""));
                    item.put("s", ev.optString("subj", ""));
                    item.put("d", d);
                } catch (JSONException ignored) { }
                hwItems.put(item);
            }
        }
        try {
            NovaWidgetStore.saveEvents(app, new JSONObject().put("v", 1).put("dots", dots).toString());
            NovaWidgetStore.saveHomework(app, new JSONObject().put("v", 1).put("items", hwItems).toString());
        } catch (JSONException ignored) { }
    }

    // ---- events: new-register homework (NEWDC) + agenda annotations (AGNT/AGHW) ----

    private JSONArray fetchEvents(String token, String studentID, int pair) {
        JSONArray out = new JSONArray();
        JSONArray hw = homeworkItems(token, studentID, pair);
        JSONArray ag = agendaItems(token, studentID, pair);
        for (int i = 0; i < hw.length(); i++) out.put(hw.opt(i));
        for (int i = 0; i < ag.length(); i++) out.put(ag.opt(i));
        return out;
    }

    private JSONArray homeworkItems(String token, String studentID, int pair) {
        String[] paths = {"/students/" + studentID + "/homeworks", "/students/" + studentID + "/homeworks/index"};
        for (String path : paths) {
            HttpResult res;
            try { res = call(path, "GET", null, token, pair); }
            catch (Exception e) { return new JSONArray(); }
            if (res.status == 404) continue;
            JSONObject j = res.json();
            if (res.status != 200 || j == null) return new JSONArray();
            JSONArray items = j.optJSONArray("items");
            if (items == null) return new JSONArray();
            JSONArray out = new JSONArray();
            for (int i = 0; i < items.length(); i++) {
                JSONObject ev = items.optJSONObject(i);
                if (ev == null || !ev.has("evtId")) continue;
                if (ev.optBoolean("homeworkDone", false)) continue;
                String date = ev.optString("expiryDate", "");
                if (date.length() < 10) continue;
                String subj = capitalize(ev.optString("subjectDesc", ""));
                String teacher = capitalize(ev.optString("teacherName", ""));
                String desc = clean(ev.optString("homeworkDesc", "Compito"), 900);
                String note = subj;
                if (!teacher.isEmpty()) note = note.isEmpty() ? teacher : note + " · " + teacher;
                JSONObject o = new JSONObject();
                try {
                    o.put("id", "hw" + ev.optInt("evtId"));
                    o.put("title", desc);
                    o.put("note", note);
                    o.put("date", date.substring(0, 10));
                    o.put("kind", "hw");
                    o.put("subj", subj);
                    o.put("teacher", teacher);
                } catch (JSONException ignored) { }
                out.put(o);
            }
            return out;
        }
        return new JSONArray();
    }

    private JSONArray agendaItems(String token, String studentID, int pair) {
        SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd", Locale.US);
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_YEAR, -7);
        String a = f.format(c.getTime());
        c.add(Calendar.DAY_OF_YEAR, 37); // -7 + 30 days ahead
        String b = f.format(c.getTime());
        String[] paths = {"/students/" + studentID + "/agendav2/all/" + a + "/" + b,
                          "/students/" + studentID + "/agenda/all/" + a + "/" + b};
        for (String path : paths) {
            JSONArray agenda;
            try {
                HttpResult res = call(path, "GET", null, token, pair);
                JSONObject j = res.json();
                if (res.status != 200 || j == null) { agenda = null; }
                else agenda = j.optJSONArray("agenda");
            } catch (Exception e) { agenda = null; }
            if (agenda == null) continue;
            JSONArray out = new JSONArray();
            for (int i = 0; i < agenda.length(); i++) {
                JSONObject ev = agenda.optJSONObject(i);
                if (ev == null) continue;
                String code = ev.optString("evtCode", "");
                if (!ev.has("evtId")) continue;
                String dtb = ev.optString("evtDatetimeBegin", "");
                if (dtb.length() < 10) continue;
                String date = dtb.substring(0, 10);
                String notes = clean(ev.optString("notes", ""), 700);
                String author = capitalize(ev.optString("authorName", ""));
                JSONObject o = new JSONObject();
                try {
                    if ("AGNT".equals(code)) {
                        if (notes.isEmpty()) continue;
                        o.put("id", "ag" + ev.optInt("evtId"));
                        o.put("title", notes);
                        o.put("note", author);
                        o.put("date", date);
                        o.put("kind", "test");
                        o.put("subj", "Verifica / annotazione");
                        o.put("teacher", author);
                    } else if ("AGHW".equals(code)) {
                        String subj = capitalize(ev.optString("subjectDesc", "Compito"));
                        String note = notes;
                        if (!author.isEmpty()) note = note.isEmpty() ? author : note + " · " + author;
                        o.put("id", "ahw" + ev.optInt("evtId"));
                        o.put("title", subj);
                        o.put("note", note);
                        o.put("date", date);
                        o.put("kind", "hw");
                        o.put("subj", subj);
                        o.put("teacher", author);
                    } else continue;
                } catch (JSONException ignored) { }
                out.put(o);
            }
            return out;
        }
        return new JSONArray();
    }

    private JSONArray gradesItems(String token, String studentID, int pair) {
        try {
            HttpResult res = call("/students/" + studentID + "/grades", "GET", null, token, pair);
            JSONObject j = res.json();
            if (res.status != 200 || j == null) return new JSONArray();
            JSONArray g = j.optJSONArray("grades");
            if (g == null) return new JSONArray();
            JSONArray out = new JSONArray();
            for (int i = 0; i < g.length(); i++) {
                JSONObject ev = g.optJSONObject(i);
                if (ev == null || !ev.has("decimalValue")) continue;
                String date = ev.optString("evtDate", "");
                if (date.length() < 10) continue;
                double v = ev.optDouble("decimalValue");
                String subj = capitalize(ev.optString("subjectDesc", ""));
                String d = date.substring(0, 10);
                String id = ev.has("evtId") ? "g" + ev.optInt("evtId") : "g" + d + subj + v;
                JSONObject o = new JSONObject();
                try {
                    o.put("id", id);
                    o.put("subj", subj);
                    o.put("date", d);
                    o.put("v", v);
                    o.put("d", ev.optString("displayValue", String.valueOf(v)));
                    o.put("n", clean(ev.optString("notesForFamily", ""), 200));
                    o.put("k", ev.optString("componentDesc", ""));
                } catch (JSONException ignored) { }
                out.put(o);
            }
            return out;
        } catch (Exception e) { return new JSONArray(); }
    }

    // ---- HTTP + helpers ----

    static final class HttpResult {
        final int status;
        final String body;
        HttpResult(int status, String body) { this.status = status; this.body = body; }
        JSONObject json() {
            try { return new JSONObject(body); } catch (JSONException e) { return null; }
        }
    }

    static HttpResult rawRequest(String url, String method, JSONObject body, int timeoutSec,
                                 String[][] headers) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setRequestMethod(method);
        conn.setConnectTimeout(timeoutSec * 1000);
        conn.setReadTimeout(timeoutSec * 1000);
        if (headers != null) {
            for (String[] h : headers) conn.setRequestProperty(h[0], h[1]);
        }
        if (body != null) {
            conn.setDoOutput(true);
            byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
            conn.setRequestProperty("Content-Length", String.valueOf(bytes.length));
            try (OutputStream os = conn.getOutputStream()) { os.write(bytes); }
        }
        int status = conn.getResponseCode();
        InputStream is = status >= 400 ? conn.getErrorStream() : conn.getInputStream();
        String text = "";
        if (is != null) {
            StringBuilder sb = new StringBuilder();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
                String line;
                while ((line = br.readLine()) != null) sb.append(line).append('\n');
            }
            text = sb.toString();
        }
        conn.disconnect();
        return new HttpResult(status, text);
    }

    private HttpResult call(String path, String method, JSONObject body, String token, int pair) throws Exception {
        List<String[]> h = new ArrayList<>();
        h.add(new String[]{"Content-Type", "application/json"});
        h.add(new String[]{"User-Agent", HEADER_PAIRS[pair][0]});
        h.add(new String[]{"Z-Dev-ApiKey", HEADER_PAIRS[pair][1]});
        if (token != null) h.add(new String[]{"Z-Auth-Token", token});
        return rawRequest(BASE + path, method, body, 25, h.toArray(new String[0][]));
    }

    private static String clean(String s, int maxLen) {
        String t = s.replaceAll("\\s+", " ").trim();
        if (t.length() > maxLen) t = t.substring(0, maxLen - 1) + "…";
        return t;
    }

    private static String capitalize(String s) {
        if (s == null || s.isEmpty()) return "";
        String lower = s.toLowerCase(Locale.ROOT);
        StringBuilder sb = new StringBuilder(lower.length());
        boolean cap = true;
        for (int i = 0; i < lower.length(); i++) {
            char ch = lower.charAt(i);
            if (cap && Character.isLetter(ch)) { sb.append(Character.toUpperCase(ch)); cap = false; }
            else sb.append(ch);
            if (ch == ' ' || ch == '-') cap = true;
        }
        return sb.toString();
    }

    static JSONObject ok() {
        JSONObject j = new JSONObject();
        try { j.put("ok", 1); } catch (JSONException ignored) { }
        return j;
    }

    static JSONObject err(String code) {
        JSONObject j = new JSONObject();
        try { j.put("ok", 0); j.put("err", code); } catch (JSONException ignored) { }
        return j;
    }

    static JSONObject errInfo(String code, String info) {
        JSONObject j = err(code);
        try { if (info != null && !info.isEmpty()) j.put("info", info); } catch (JSONException ignored) { }
        return j;
    }
}
