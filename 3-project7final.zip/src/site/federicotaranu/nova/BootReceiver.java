package site.federicotaranu.nova;
import android.content.*;public class BootReceiver extends BroadcastReceiver{public void onReceive(Context c,Intent i){if(!Intent.ACTION_BOOT_COMPLETED.equals(i.getAction()))return;Notifications.restore(c);RegisterJob.schedule(c);NovaWidget.refresh(c);}}
