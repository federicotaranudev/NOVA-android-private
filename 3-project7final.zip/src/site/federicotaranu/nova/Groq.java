package site.federicotaranu.nova;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Groq chatbot client (api.groq.com, NOT xAI Grok). Android port of the iOS bridge.
 * Ops: has / clear / set / chat / vision. The API key is validated on set and kept
 * only in the Keystore-backed SecureStore (via SecretBox). Off-main-thread only.
 *
 * Groq retires models fast (llama-4 vision off mid-2026, llama-3.x chat off Aug 2026).
 * Live as of Oct 2026: gpt-oss for chat, qwen3.8-27b for vision.
 * Check console.groq.com/docs/deprecations before updating these lists.
 */
final class Groq {
    private static final String BASE = "https://api.groq.com/openai/v1";
    private static final String[] CHAT_MODELS = {"openai/gpt-oss-120b", "openai/gpt-oss-20b", "qwen/qwen3.8-27b"};
    private static final String[] VISION_MODELS = {"qwen/qwen3.8-27b"};

    private final SecretBox secrets;

    Groq(SecretBox secrets) { this.secrets = secrets; }

    JSONObject handle(JSONObject msg) {
        switch (msg.optString("op", "")) {
            case "has": {
                JSONObject r = ClasseViva.ok();
                try { r.put("has", secrets.get("groq") != null ? 1 : 0); } catch (JSONException ignored) { }
                return r;
            }
            case "clear":
                secrets.remove("groq");
                return ClasseViva.ok();
            case "set":
                return setKey(msg.optString("key", ""));
            case "chat":
                return chat(msg);
            case "vision":
                return vision(msg);
            default:
                return ClasseViva.err("op");
        }
    }

    private JSONObject setKey(String raw) {
        String key = raw.trim();
        if (key.startsWith("xai-")) return ClasseViva.err("grok");
        if (!key.startsWith("gsk_") || key.length() <= 20) return ClasseViva.err("formato");
        try {
            ClasseViva.HttpResult res = ClasseViva.rawRequest(BASE + "/models", "GET", null, 20,
                    new String[][]{{"Authorization", "Bearer " + key}});
            if (res.status == 401 || res.status == 403) return ClasseViva.err("key");
            if (res.status != 200) return ClasseViva.errInfo("rete", "HTTP " + res.status);
        } catch (Exception e) {
            return ClasseViva.err("rete");
        }
        secrets.put("groq", key);
        return ClasseViva.ok();
    }

    private JSONObject chat(JSONObject msg) {
        String key = secrets.get("groq");
        if (key == null) return ClasseViva.err("nokey");
        org.json.JSONArray msgs = msg.optJSONArray("messages");
        if (msgs == null) msgs = new org.json.JSONArray();
        for (String model : CHAT_MODELS) {
            JSONObject body = new JSONObject();
            try {
                body.put("model", model);
                body.put("messages", msgs);
                body.put("temperature", 0.5);
                body.put("max_tokens", 2500);
                body.put("reasoning_effort", "low");
            } catch (JSONException e) { return ClasseViva.err("op"); }
            JSONObject r = completion(key, body, 60);
            if (r != null) {
                int status = r.optInt("_status");
                String text = extractText(r);
                if (status == 200 && text != null) {
                    JSONObject out = ClasseViva.ok();
                    try { out.put("text", text); out.put("model", model); } catch (JSONException ignored) { }
                    return out;
                }
                if (status == 401 || status == 403) return ClasseViva.err("key");
                if (status == 429) return ClasseViva.err("limite");
            } else {
                return ClasseViva.err("rete");
            }
        }
        return ClasseViva.err("modello");
    }

    private JSONObject vision(JSONObject msg) {
        String key = secrets.get("groq");
        if (key == null) return ClasseViva.err("nokey");
        String prompt = msg.optString("prompt", "");
        String img = msg.optString("img", "");
        if (!img.startsWith("data:image/")) return ClasseViva.err("img");
        String lastInfo = "";
        for (String model : VISION_MODELS) {
            JSONObject body = new JSONObject();
            try {
                org.json.JSONArray content = new org.json.JSONArray();
                content.put(new JSONObject().put("type", "text").put("text", prompt));
                content.put(new JSONObject().put("type", "image_url")
                        .put("image_url", new JSONObject().put("url", img)));
                body.put("model", model);
                body.put("messages", new org.json.JSONArray()
                        .put(new JSONObject().put("role", "user").put("content", content)));
                body.put("temperature", 0);
                body.put("max_tokens", 3000);
                body.put("reasoning_effort", "none");
                body.put("response_format", new JSONObject().put("type", "json_object"));
            } catch (JSONException e) { return ClasseViva.err("op"); }
            JSONObject r = completion(key, body, 90);
            if (r != null) {
                int status = r.optInt("_status");
                String text = extractText(r);
                if (status == 200 && text != null) {
                    JSONObject out = ClasseViva.ok();
                    try { out.put("text", text); out.put("model", model); } catch (JSONException ignored) { }
                    return out;
                }
                if (status == 401 || status == 403) return ClasseViva.err("key");
                if (status == 429) return ClasseViva.err("limite");
                lastInfo = r.optString("_body", "");
                if (lastInfo.length() > 300) lastInfo = lastInfo.substring(0, 300);
            } else {
                return ClasseViva.err("rete");
            }
        }
        return ClasseViva.errInfo("modello", lastInfo);
    }

    /** POST /chat/completions. Returns the parsed body with _status/_body injected, or null on network failure. */
    private JSONObject completion(String key, JSONObject body, int timeoutSec) {
        try {
            ClasseViva.HttpResult res = ClasseViva.rawRequest(BASE + "/chat/completions", "POST", body, timeoutSec,
                    new String[][]{{"Authorization", "Bearer " + key}, {"Content-Type", "application/json"}});
            JSONObject j = res.json();
            if (j == null) j = new JSONObject();
            j.put("_status", res.status);
            j.put("_body", res.body);
            return j;
        } catch (Exception e) { return null; }
    }

    private static String extractText(JSONObject j) {
        try {
            return j.getJSONArray("choices").getJSONObject(0)
                    .getJSONObject("message").getString("content");
        } catch (JSONException e) { return null; }
    }
}
