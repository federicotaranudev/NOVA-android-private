package site.federicotaranu.nova;
import android.app.job.*;import android.content.*;
public class RegisterJob extends JobService{
 public boolean onStartJob(JobParameters p){new Thread(()->{NovaIntegrations n=new NovaIntegrations(this,(id,r)->{});n.setEventsListener((events,bg)->{Homework.process(this,events,bg);NovaWidget.refresh(this);});n.backgroundRefresh();jobFinished(p,false);}).start();return true;}
 public boolean onStopJob(JobParameters p){return true;}
 static void schedule(Context c){JobScheduler j=(JobScheduler)c.getSystemService(Context.JOB_SCHEDULER_SERVICE);j.schedule(new JobInfo.Builder(702,new ComponentName(c,RegisterJob.class)).setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setPersisted(true).setPeriodic(2*60*60*1000L).build());}
}
