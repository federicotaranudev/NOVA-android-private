# Android7 parity audit, 24 October 2026
Baseline: delivered iOS24.6 and Android6, exact bundled HTML inspected.

Shared screens/features retained: onboarding/profile/accounts/settings, cards/preferences, tasks/calendar/reminders/focus, AI chat+vision, ClasseViva import/grades, Spotify controls, map/friends/privacy, friend requests/chat/text/photo/audio/read state/typing, QR and avatars, sync, diagnostics, cinematic narrated intro. Android HTML differs for secure native bridge, bundled libraries, native labels, timeout/layout/profile retry fixes; it was not replaced with iOS HTML.

Android-native counterparts already present: encrypted local service credentials, biometric/device-code gate, permission handling, camera/microphone WebView capture, file chooser, notification alarms, reboot restore, periodic register fetch, foreground opt-in location sharing with persistent notification, stop on ghost/logout, external browser OAuth with PKCE+state. Live service success and OEM background delivery require device validation, not inferred from code.

Added/fixed in7:
- Separate current/next subject widget with native ticking countdown and sampled progress; today's lessons widget; end-of-school widget with ticking countdown; target-day homework widget. Existing month and combined legacy widgets retained to preserve pinned widgets.
- Personal timetable only, no guessed built-in timetable. Rome school dates, room labels, weekend homework target Monday, nearest future school day. Refresh at lesson boundaries/midnight and app sync; exact-alarm access determines timing, system delays possible.
- Distinct Android haptic patterns, narration word accents/heartbeat and finale pattern with cancellation. Hardware-dependent approximation, not Apple Core Haptics.
- Battery state updates and screen awake only while charging; silent/vibrate modes do not speak intro.
- Focus cancellation actually cancels scheduled finish alarm. Homework-off cancels AI plans too; AI plan clears automatic duplicate schedule. Notification lists sorted before cap.
- Lock availability returned, no device-code removal trap, repeated biometric prompt guard. Biometric hardware differences remain.

Platform boundaries:
- Apple accessory inline/rectangular/circular widgets belong to iOS lock screen and are not Android home-widget types. Not claiming them implemented. Android launcher/lock-screen widget availability is OS/OEM-specific.
- Android lacks Apple's WidgetKit timeline and Core Haptics semantics. Native chronometer ticks independently; progress samples update with widget refresh rather than a per-second app service. No battery-draining always-running widget service.
- All third-party services require internet, owner's credentials and their own availability. No credential collection, new permission opt-in, sharing default or paid service added.
