#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
SDK=${ANDROID_HOME:-/tmp/android-sdk}
JAVA=${JAVA_HOME:-/tmp/jdk17}
BT="$SDK/build-tools/35.0.0"
PLATFORM=${NOVA_COMPILE_PLATFORM:-android-37.2}
rm -rf build;mkdir -p build/{gen,classes,dex}
"$BT/aapt2" compile --dir res -o build/res.zip
"$BT/aapt2" link -o build/base.apk -I "$SDK/platforms/$PLATFORM/android.jar" --manifest AndroidManifest.xml --java build/gen -R build/res.zip -A assets --auto-add-overlay
"$JAVA/bin/javac" -encoding UTF-8 --release 8 -classpath "$SDK/platforms/$PLATFORM/android.jar" -d build/classes $(find src build/gen -name '*.java')
"$JAVA/bin/java" -cp "$BT/lib/d8.jar" com.android.tools.r8.D8 --lib "$SDK/platforms/$PLATFORM/android.jar" --min-api 26 --output build/dex $(find build/classes -name '*.class')
(cd build/dex;zip -q ../base.apk classes*.dex)
"$BT/zipalign" -f -p 4 build/base.apk build/aligned.apk
"$BT/apksigner" sign --ks "${NOVA_KEYSTORE:?Set private keystore path}" --ks-key-alias nova --ks-pass "file:${NOVA_KEYPASS_FILE:?Set private password-file path}" --out build/NOVA-2026.10.24.android.3-test.apk build/aligned.apk
"$BT/apksigner" verify --verbose --print-certs build/NOVA-2026.10.24.android.3-test.apk
